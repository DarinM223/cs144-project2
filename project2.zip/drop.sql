/* SQL statements to drop the tables necessary for the application */

DROP TABLE IF EXISTS ItemCategory;
DROP TABLE IF EXISTS Item;
DROP TABLE IF EXISTS Bidder;
DROP TABLE IF EXISTS Seller;
DROP TABLE IF EXISTS Bid;
